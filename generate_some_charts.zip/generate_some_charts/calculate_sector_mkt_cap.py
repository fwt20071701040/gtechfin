import numpy as np
import MySQLdb
import cons_for_jqdata
import cons_for_jqdata_test
import pandas as pd
import datetime
def get_sector_ids(cur, sectors):
    sector_id_list = []
    for sector in sectors:
        sql = "select security_lookup_id from stock_sector_for_risk where mkt_sector=%s"
        cur.execute(sql,(sector,))
        sector_id_list.append(cur.fetchall())
    return sector_id_list

def get_mkt_sectors(cur):
    sql = "select mkt_sector from stock_sector_for_risk group by mkt_sector"
    cur.execute(sql)
    return cur.fetchall()

def calculate_sector_cap(cur, sector_id_list):
    sector_sum_cap_map = []
    for sector_ids in sector_id_list:
        sector_ids_list = []
        for sector_id in sector_ids:
            sector_id = sector_id[0]
            sector_ids_list.append(sector_id)
        sql = "select time_x,sum(close_x * volume) from security_day_price_cn where security_lookup_id in " + str(tuple(sector_ids_list)) +" group by time_x"
        print(sql)
        cur.execute(sql)
        sector_all_sum = cur.fetchall()
        sector_sum_cap_map.append(sector_all_sum)
    return sector_sum_cap_map

def insert_into_gtechfintest(cur, sectors, sector_caps_map):
    len_1 = len(sector_caps_map)
    data_list = []
    sql = "INSERT INTO sector_mkt_cap_cn(mkt_sector,time_x,mkt_cap)" \
          "VALUES (%s,%s,%s)" \
          "ON DUPLICATE KEY UPDATE " \
          "mkt_cap=VALUES(mkt_cap)"
    for first_out_index in range(len(sector_caps_map)):
        for out_index in range(len(sector_caps_map[first_out_index])):
            t = (sectors[first_out_index], sector_caps_map[first_out_index][out_index][0], sector_caps_map[first_out_index][out_index][1])
            data_list.append(t)
    cur.executemany(sql, data_list)

conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port,charset="utf8")
cur = conn.cursor()

sectors = get_mkt_sectors(cur)
sector_id_list = get_sector_ids(cur, sectors)
sector_caps_map = calculate_sector_cap(cur, sector_id_list)
cur.close()
conn.close()
conn = MySQLdb.connect(user=cons_for_jqdata_test.db_user, passwd=cons_for_jqdata_test.db_passwd, host=cons_for_jqdata_test.db_host,
                           db=cons_for_jqdata_test.db_name, port=cons_for_jqdata_test.db_port, charset="utf8")
cur = conn.cursor()
insert_into_gtechfintest(cur, sectors, sector_caps_map)
conn.commit()
conn.close()
print("the sector data has been inserted into the database")
