from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import datetime
import re
import cons_for_jqdata
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
print("start to update")
now1 = datetime.datetime.now()
now_string = now1.strftime("%Y-%m-%d %H:%M:%S")
indexes_symbol = get_all_securities(['index']).index.values
tickers_and_ids_index = jqdata_helper.get_all_id_and_ticker(conn, True)
for index in range(len(indexes_symbol)):
    index_symbol_nomalized = re.sub("\D", "", indexes_symbol[index])
    correspond_id = tickers_and_ids_index.get(index_symbol_nomalized)
    specified_index_latest_time = jqdata_helper.get_specified_id_latest_time(conn, correspond_id)
    if specified_index_latest_time is None:
        jqdata_helper.insert_history_all_stocks_ticks(indexes_symbol,index,now1,conn)
    specified_index_latest_time = specified_index_latest_time[0] + datetime.timedelta(days=-2)
    jqdata_helper.insert_latest_indexes_ticks(indexes_symbol, index, now1, conn, specified_index_latest_time)
stocks_symbol = get_all_securities(['stock']).index.values
tickers_and_ids_stock = jqdata_helper.get_all_id_and_ticker(conn, False)
for index in range(len(stocks_symbol)):
    stock_symbol_nomalized = re.sub("\D", "", stocks_symbol[index])
    correspond_id = tickers_and_ids_stock.get(stock_symbol_nomalized)
    specified_stock_latest_time = jqdata_helper.get_specified_id_latest_time(conn, correspond_id)
    if specified_stock_latest_time is None:
        jqdata_helper.insert_history_all_indexes_ticks(stocks_symbol,index,now1,conn)
    specified_stock_latest_time = specified_stock_latest_time[0] + datetime.timedelta(days=-2)
    jqdata_helper.insert_latest_stocks_ticks(stocks_symbol, index, now1, conn, specified_stock_latest_time)
print("update has completed")