from jqdatasdk import *
import pymysql
import gevent
import time
import jqdatasdk
from helper import jqdata_helper
import re
import numpy as np
import datetime
import pandas as pd


class MyPyMysql:
    def __init__(self, host, port, username, password, db, charset='utf8'):
        self.host = host  # mysql主机地址
        self.port = port  # mysql端口
        self.username = username  # mysql远程连接用户名
        self.password = password  # mysql远程连接密码
        self.db = db  # mysql使用的数据库名
        self.charset = charset  # mysql使用的字符编码,默认为utf8
        self.pymysql_connect()  # __init__初始化之后，执行的函数

    def pymysql_connect(self):
        # pymysql连接mysql数据库
        # 需要的参数host,port,user,password,db,charset
        self.conn = pymysql.connect(host=self.host,
                                    port=self.port,
                                    user=self.username,
                                    password=self.password,
                                    db=self.db,
                                    charset=self.charset
                                    )
        # 连接mysql后执行的函数
        self.asynchronous()

    def run(self,index):

        jqdatasdk.auth('17154837278', '837278')
        now1 = datetime.datetime.now()
        codes = get_all_securities(['stock']).index.values

        # for index in range(len(codes)):
        code_num = re.sub("\D", "", codes[index])

        cur = self.conn.cursor()
        sql = "select id from security_lookup_cn where TICKER = '{}' and (sector is null or sector != 'index')".format(
            code_num)
        cur.execute(sql)
        stock_id = cur.fetchall()
        cur.close()
        if stock_id == ():
            return
        now2 = datetime.datetime.now()
        now_string = now2.strftime("%Y-%m-%d %H:%M:%S")
        start_time1 = "2004-12-01 23:00:00"
        end_time1 = "2008-01-01 23:00:00"
        start_time2 = "2008-01-01 23:00:00"
        end_time2 = "2011-01-01 23:00:00"
        start_time3 = "2011-01-01 23:00:00"
        end_time3 = "2014-01-01 23:00:00"
        start_time4 = "2014-01-01 23:00:00"
        end_time4 = "2017-01-01 23:00:00"
        start_time5 = "2017-01-01 23:00:00"
        end_time5 = now_string
        df1 = get_price(codes[index], start_date=start_time1, end_date=end_time1, frequency='minute')
        df2 = get_price(codes[index], start_date=start_time2, end_date=end_time2, frequency='minute')
        df3 = get_price(codes[index], start_date=start_time3, end_date=end_time3, frequency='minute')
        df4 = get_price(codes[index], start_date=start_time4, end_date=end_time4, frequency='minute')
        df5 = get_price(codes[index], start_date=start_time5, end_date=end_time5, frequency='minute')
        df = pd.concat([df1, df2, df3, df4, df5], axis=0).dropna(0)

        # 创建游标
        self.cur = self.conn.cursor()

        # 定义sql语句,插入数据id,name,gender,email
        sql = "INSERT INTO security_min_price_cn_test2(SECURITY_LOOKUP_ID,TICKER,time_x,OPEN_X, HIGH, LOW, CLOSE_X, VOLUME,ADJ_CLOSE) " \
              "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        # 定义总插入行数为一个空列表
        data_list = []

        for i in range(0, len(df)):
            time_struct = df.index[i].timetuple()#协程和异步操作要转tuple
            # time_tuple = time.gmtime(time_struct)
            # time_datetime = datetime.datetime.fromtimestamp(time_struct)
            # time_local = time.strftime(format(time_struct))
            t = (stock_id[0], code_num, time_struct, np.float(df['open'][i]), np.float(df['high'][i]),
                 np.float(df['low'][i])
                 , np.float(df['close'][i]), np.float(df['volume'][i]), np.float(df['money'][i]))
            data_list.append(t)

        # 执行多行插入，executemany(sql语句,数据(需一个元组类型))
        content = self.cur.executemany(sql, data_list)
        if content:
            print('成功插入数据')

        # 提交数据,必须提交，不然数据不会保存
        self.conn.commit()

    def asynchronous(self):
        # g_l 任务列表
        # 定义了异步的函数: 这里用到了一个gevent.spawn方法
        max_line = 10000  # 定义每次最大插入行数(max_line=10000,即一次插入10000行)
        g_l = [gevent.spawn(self.run, i) for i in range(0, 3)]
        # for i in range(0, 3)
        # gevent.joinall 等待所以操作都执行完毕
        gevent.joinall(g_l)
        self.cur.close()  # 关闭游标
        self.conn.close()  # 关闭pymysql连接


if __name__ == '__main__':
    start_time = time.time()  # 计算程序开始时间
    st = MyPyMysql('gz-cdb-qa6dqlyi.sql.tencentcdb.com', 62589, 'siweixie', 'siweixie', 'gtechfintest')  # 实例化类，传入必要参数
    print('程序耗时{:.2f}'.format(time.time() - start_time))  # 计算程序总耗时