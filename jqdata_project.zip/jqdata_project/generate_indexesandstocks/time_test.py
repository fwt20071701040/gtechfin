from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import cons_for_jqdata
# df_all = pd.DataFrame()

jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)

now1 = datetime.datetime.now()
now_string = now1.strftime("%Y-%m-%d %H:%M:%S")
ticker = '000001'
time_x = jqdata_helper.get_specified_ticker_latest_time(conn, 'index', ticker)
time_x = time_x[0]
time_x += datetime.timedelta(minutes=1)
print(time_x)