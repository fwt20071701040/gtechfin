from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re


# df_all = pd.DataFrame()
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
now1 = datetime.datetime.now()
now_string = now1.strftime("%Y-%m-%d %H:%M:%S")
# print(now_string)
indexes_symbol = get_all_securities(['index']).index.values
tickers_and_ids_index = jqdata_helper.get_all_id_and_ticker(conn, True)
all_saved_ids = jqdata_helper.get_all_ids_from_min_price(conn)
indexes_symbol_nomalized_list = []
not_saved_index_symbol_list = []
for index_symbol in indexes_symbol:
    indexes_symbol_nomalized = re.sub("\D", "", index_symbol)
    indexes_symbol_nomalized_list.append(indexes_symbol_nomalized)
    correspond_id = tickers_and_ids_index.get(indexes_symbol_nomalized)
    correspond_id = (correspond_id,)
    if correspond_id not in list(all_saved_ids):
        not_saved_index_symbol_list.append(index_symbol)
g_l = [gevent.spawn(jqdata_helper.insert_history_all_indexes_ticks, not_saved_index_symbol_list, index, now1, conn) for index in
       range(len(not_saved_index_symbol_list))]
gevent.joinall(g_l)
# for index in range(len(indexes_symbol)):
#     jqdata_helper.insert_indexes_ticks(indexes_symbol, index, now1, conn)
print("all indexes have been inserted into the database")
stocks_symbol = get_all_securities(['stock']).index.values
stocks_symbol_nomalized_list = []
stock_ids = []
not_saved_stock_symbol_list = []
tickers_and_ids_stock = jqdata_helper.get_all_id_and_ticker(conn, False)
for stock_symbol in stocks_symbol:
    stock_symbol_nomalized = re.sub("\D", "", stock_symbol)
    stocks_symbol_nomalized_list.append(stock_symbol_nomalized)
    correspond_id = tickers_and_ids_stock.get(stock_symbol_nomalized)
    correspond_id = (correspond_id,)
    if correspond_id not in list(all_saved_ids):
        not_saved_stock_symbol_list.append(stock_symbol)
g_l = [gevent.spawn(jqdata_helper.insert_history_all_stocks_ticks, not_saved_stock_symbol_list, index, now1, conn) for index in
       range(len(not_saved_stock_symbol_list))]
gevent.joinall(g_l)
print("all stocks have been inserted into the database")


