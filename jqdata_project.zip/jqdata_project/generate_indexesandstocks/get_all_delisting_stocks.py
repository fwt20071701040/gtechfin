from jqdatasdk import *
import jqdatasdk
import datetime
import cons_for_jqdata

jqdatasdk.auth(cons_for_jqdata.jq_user_normal, cons_for_jqdata.jq_passwd_normal)
now1 = datetime.datetime.now()
now_string = now1.strftime("%Y-%m-%d %H:%M:%S")
# codes = get_all_securities(['stock']).end_date != '2200-01-01'
codes = get_all_securities([])
filtered_codes = codes[codes['end_date'] != '2200-01-01']
price = get_price("000022.XSHE", start_date='2018-12-20', end_date='2019-1-10', frequency='minute')
print(price)