from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import cons_for_jqdata
# df_all = pd.DataFrame()

jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)

now1 = datetime.datetime.now()
now_string = now1.strftime("%Y-%m-%d %H:%M:%S")
ticker_list = []
ticker = '000001.XSHG'
ticker_list.append(ticker)
specified_index_latest_time = jqdata_helper.get_specified_ticker_latest_time(conn, 'index', ticker)
specified_index_latest_time = specified_index_latest_time[0] + datetime.timedelta(minutes=1)
jqdata_helper.insert_latest_indexes_ticks(ticker_list, 0, now1, conn,specified_index_latest_time)
