from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import datetime
import re
from helper.jqdata_helper_alter import *
import cons_for_jqdata
jqdata_helper1 = JqdataHelper(cons_for_jqdata.db_user, cons_for_jqdata.db_passwd, cons_for_jqdata.db_host,
                            cons_for_jqdata.db_name, cons_for_jqdata.db_port,cons_for_jqdata.jq_user_super,
                              cons_for_jqdata.jq_passwd_super, 'index')
print("start to update")
indexes_symbol = get_all_securities(['index']).index.values
tickers_and_ids_index = jqdata_helper1.get_all_id_and_ticker(True)
for index in range(len(indexes_symbol)):
    index_symbol_nomalized = re.sub("\D", "", indexes_symbol[index])
    correspond_id = tickers_and_ids_index.get(index_symbol_nomalized)
    specified_index_latest_time = jqdata_helper1.get_specified_id_latest_time(correspond_id)
    if specified_index_latest_time is None:
        jqdata_helper1.insert_history_all_stocks_ticks(indexes_symbol,index)
    specified_index_latest_time = specified_index_latest_time[0] + datetime.timedelta(days=-2)
    jqdata_helper1.insert_latest_indexes_ticks(index, specified_index_latest_time)
jqdata_helper1 = JqdataHelper(cons_for_jqdata.db_user, cons_for_jqdata.db_passwd, cons_for_jqdata.db_host,
                            cons_for_jqdata.db_name, cons_for_jqdata.db_port,cons_for_jqdata.jq_user_super,
                              cons_for_jqdata.jq_passwd_super, 'stock')
stocks_symbol = get_all_securities(['stock']).index.values
tickers_and_ids_stock = jqdata_helper1.get_all_id_and_ticker(False)
for index in range(len(stocks_symbol)):
    stock_symbol_nomalized = re.sub("\D", "", stocks_symbol[index])
    correspond_id = tickers_and_ids_stock.get(stock_symbol_nomalized)
    specified_stock_latest_time = jqdata_helper1.get_specified_id_latest_time(correspond_id)
    if specified_stock_latest_time is None:
        jqdata_helper1.insert_history_all_indexes_ticks(stocks_symbol,index)
    specified_stock_latest_time = specified_stock_latest_time[0] + datetime.timedelta(days=-2)
    jqdata_helper1.insert_latest_stocks_ticks(index, specified_stock_latest_time)
print("update has completed")