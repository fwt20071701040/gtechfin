from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import cons_for_jqdata

jqdatasdk.auth(cons_for_jqdata.jq_user_normal, cons_for_jqdata.jq_passwd_normal)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
cur = conn.cursor()
codes = get_all_securities(['stock']).index.values
q = query(
    valuation
).filter(
    valuation.code.in_(codes)
)
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
df = get_fundamentals(q, now)
sql = "INSERT INTO 70_screener_cn(security_lookup_id,ticker,update_time, market_cap, p_e, p_b, p_s, p_fcf)"\
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
data_list = []
print(len(df))
for i in range(len(df)):
    code_num = re.sub("\D", "", df['code'][i])
    security_lookup_id = jqdata_helper.get_id_by_ticker_and_sector(conn, code_num, 'stock')
    data_tuple = (security_lookup_id[0], code_num, df['day'][i], df['market_cap'][i] * pow(10, 8), df['pe_ratio_lyr'][i],
                  df['pb_ratio'][i], df['ps_ratio'][i], df['pcf_ratio'][i])
    data_list.append(data_tuple)
cur.executemany(sql, data_list)
cur.close()
conn.commit()