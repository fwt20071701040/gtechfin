from jqdatasdk import *
import jqdatasdk
from helper import jqdata_helper
import MySQLdb
import datetime
import re
import cons_for_jqdata

jqdatasdk.auth(cons_for_jqdata.jq_user_normal, cons_for_jqdata.jq_passwd_normal)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
cur = conn.cursor()
codes = get_all_securities(['stock']).index.values
q = query(
    valuation
).filter(
    valuation.code.in_(codes)
)
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
df = get_fundamentals(q, now)
sql = "INSERT INTO 70_screener_cn(security_lookup_id,ticker,update_time, market_cap, p_e, p_b, p_s, p_fcf)"\
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE ticker=VALUES(ticker),update_time=VALUES(update_time),market_cap=VALUES(market_cap)," \
      "p_e=VALUES(p_e),p_b=VALUES(p_b),p_s=VALUES(p_s),p_fcf=VALUES(p_fcf)"
data_list = []
print(len(df))
for i in range(len(df)):
    code_num = re.sub("\D", "", df['code'][i])
    security_lookup_id = jqdata_helper.get_id_by_ticker_and_sector(conn, code_num, 'stock')
    data_tuple = (security_lookup_id[0], code_num, df['day'][i], df['market_cap'][i] * pow(10, 8), df['pe_ratio_lyr'][i],
                  df['pb_ratio'][i], df['ps_ratio'][i], df['pcf_ratio'][i])
    data_list.append(data_tuple)
cur.executemany(sql, data_list)
codes = get_all_securities(['stock']).index.values
q = query(
    cash_flow
).filter(
    cash_flow.code.in_(codes)
)
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
df = get_fundamentals(q, now)
sql = "UPDATE 70_screener_cn SET dividend = %s where security_lookup_id =%s"

data_list = []
for i in range(len(df)):
    code_num = re.sub("\D", "", df['code'][i])
    security_lookup_id = jqdata_helper.get_id_by_ticker_and_sector(conn, code_num, 'stock')
    if security_lookup_id is not None:
        data_tuple = (df['dividend_interest_payment'][i], security_lookup_id[0])
        data_list.append(data_tuple)
codes = get_all_securities(['stock']).index.values
q = query(
    income
).filter(
    income.code.in_(codes)
)
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
df = get_fundamentals(q, now)
sql = "UPDATE 70_screener_cn SET earnings = %s where security_lookup_id =%s"

data_list = []
for i in range(len(df)):
    code_num = re.sub("\D", "", df['code'][i])
    security_lookup_id = jqdata_helper.get_id_by_ticker_and_sector(conn, code_num, 'stock')
    if security_lookup_id is not None:
        data_tuple = (df['net_profit'][i], security_lookup_id[0])
        data_list.append(data_tuple)
cur.executemany(sql, data_list)
codes = get_all_securities(['stock']).index.values
q = query(
    indicator
).filter(
    indicator.code.in_(codes)
)
now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
df = get_fundamentals(q, now)
sql = "UPDATE 70_screener_cn SET eps = %s, roe = %s, roa = %s, profit_m = %s, gross_m = %s, oper_m = %s where security_lookup_id =%s"
data_list = []
for i in range(len(df)):
    code_num = re.sub("\D", "", df['code'][i])
    security_lookup_id = jqdata_helper.get_id_by_ticker_and_sector(conn, code_num, 'stock')
    if security_lookup_id is not None:
        data_tuple = (df['eps'][i], df['roe'][i], df['roa'][i], df['net_profit_margin'][i], df['gross_profit_margin'][i],
                  df['operating_expense_to_total_revenue'][i], security_lookup_id[0])
        data_list.append(data_tuple)
cur.executemany(sql, data_list)
cur.close()
conn.commit()