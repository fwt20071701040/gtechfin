# projects
从聚宽平台取出每只股票的历史分钟数据，然后存入到数据库，
启动generate_indexesandstocks_main.py插入历史股票
启动update_latest_ticks.py进行数据更新
启用后缀是alter的相应文件依然可以完成任务
#关于70_screener_cn表的生成和更新
运行generate_70screenercn_main.py文件即可
#关于sector_mkt_cap_cn表的生成和更新
直接运行calculate_sector_mkt_cap即可
#关于generate_finance_fundamental项目
运行项目中的9个程序，分别生成数据库中对应的9张财务报表
程序中的df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
count初始值设置为20000，用于取出财务报表历史数据
如果以后要更新最新数据，建议把此值设置为200