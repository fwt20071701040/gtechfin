from jqdatasdk import *
from helper import jqdata_helper
import re
import numpy as np
import MySQLdb
import cons_for_jqdata
import pandas as pd
import datetime
def get_coin_id(cur, ticker, sec_short_name):
    sql = "select ID from security_lookup_coin where TICKER = %s and NAME_X = %s"

    cur.execute(sql,(ticker, sec_short_name))
    return cur.fetchone()
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port,charset="utf8")
cur = conn.cursor()
df = pd.read_csv('D:/新建文件夹/数字货币/优矿数字货币信息/cryptoCurrency.csv',encoding='GBK')
sql = "INSERT INTO 70_screener_coin(id, coinName,secShortName,algorithm, proofType, fullPremined, totalCoinSupply, description, listDate)"\
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
df = df.fillna('Null')
data_list = []
for i in range(len(df)):
    # print(df['coinName'][i], df['secShortName'][i], df['alogorithm'][i], df['proofType'][i], df['fullPremined'][i],
    #               df['totalCoinSupply'][i], df['description'][i], df['listDate'][i])
    if df['listDate'][i] == 'Null':
        df_datetime_nomalize = "2200-01-01"
    else:
        df_datetime_nomalize = df['listDate'][i]
    coin_id = get_coin_id(cur, df['coinName'][i], df['secShortName'][i])
    print(coin_id)
    df_datetime = datetime.datetime.strptime(df_datetime_nomalize, "%Y-%m-%d")
    if coin_id is not None:
        data_tuple = (coin_id[0], df['coinName'][i], df['secShortName'][i], df['alogorithm'][i], df['proofType'][i], df['fullPremined'][i],
                    df['totalCoinSupply'][i], df['description'][i], df_datetime)
        data_list.append(data_tuple)
cur.executemany(sql, data_list)
cur.close()
conn.commit()