from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["cash_equivalents"].values[i],
                 df.minor_xs(stock_symbol)["settlement_provi"].values[i]
            , df.minor_xs(stock_symbol)["lend_capital"].values[i], df.minor_xs(stock_symbol)["trading_assets"].values[i], df.minor_xs(stock_symbol)["bill_receivable"].values[i],
                 df.minor_xs(stock_symbol)["account_receivable"].values[i],df.minor_xs(stock_symbol)["advance_payment"].values[i], df.minor_xs(stock_symbol)["insurance_receivables"].values[i],
                 df.minor_xs(stock_symbol)["reinsurance_receivables"].values[i],
            df.minor_xs(stock_symbol)["reinsurance_contract_reserves_receivable"].values[i], df.minor_xs(stock_symbol)["interest_receivable"].values[i], df.minor_xs(stock_symbol)["dividend_receivable"].values[i],
                 df.minor_xs(stock_symbol)["other_receivable"].values[i], df.minor_xs(stock_symbol)["bought_sellback_assets"].values[i], df.minor_xs(stock_symbol)["inventories"].values[i]
            , df.minor_xs(stock_symbol)["non_current_asset_in_one_year"].values[i], df.minor_xs(stock_symbol)["other_current_assets"].values[i], df.minor_xs(stock_symbol)["total_current_assets"].values[i],
                 df.minor_xs(stock_symbol)["loan_and_advance"].values[i],
             df.minor_xs(stock_symbol)["hold_for_sale_assets"].values[i], df.minor_xs(stock_symbol)["hold_to_maturity_investments"].values[i], df.minor_xs(stock_symbol)["longterm_receivable_account"].values[i],
                 df.minor_xs(stock_symbol)["longterm_equity_invest"].values[i], df.minor_xs(stock_symbol)["investment_property"].values[i], df.minor_xs(stock_symbol)["fixed_assets"].values[i],
                 df.minor_xs(stock_symbol)["constru_in_process"].values[i], df.minor_xs(stock_symbol)["construction_materials"].values[i], df.minor_xs(stock_symbol)["fixed_assets_liquidation"].values[i]
            , df.minor_xs(stock_symbol)["biological_assets"].values[i], df.minor_xs(stock_symbol)["oil_gas_assets"].values[i], df.minor_xs(stock_symbol)["intangible_assets"].values[i],
                 df.minor_xs(stock_symbol)["development_expenditure"].values[i],
             df.minor_xs(stock_symbol)["good_will"].values[i], df.minor_xs(stock_symbol)["long_deferred_expense"].values[i], df.minor_xs(stock_symbol)["deferred_tax_assets"].values[i],
                 df.minor_xs(stock_symbol)["other_non_current_assets"].values[i], df.minor_xs(stock_symbol)["total_non_current_assets"].values[i], df.minor_xs(stock_symbol)["total_assets"].values[i],
                 df.minor_xs(stock_symbol)["shortterm_loan"].values[i], df.minor_xs(stock_symbol)["borrowing_from_centralbank"].values[i], df.minor_xs(stock_symbol)["deposit_in_interbank"].values[i]
            , df.minor_xs(stock_symbol)["borrowing_capital"].values[i], df.minor_xs(stock_symbol)["trading_liability"].values[i], df.minor_xs(stock_symbol)["notes_payable"].values[i],
                 df.minor_xs(stock_symbol)["accounts_payable"].values[i],
             df.minor_xs(stock_symbol)["advance_peceipts"].values[i], df.minor_xs(stock_symbol)["sold_buyback_secu_proceeds"].values[i], df.minor_xs(stock_symbol)["commission_payable"].values[i],
                 df.minor_xs(stock_symbol)["salaries_payable"].values[i], df.minor_xs(stock_symbol)["taxs_payable"].values[i], df.minor_xs(stock_symbol)["interest_payable"].values[i],
                 df.minor_xs(stock_symbol)["dividend_payable"].values[i], df.minor_xs(stock_symbol)["other_payable"].values[i], df.minor_xs(stock_symbol)["reinsurance_payables"].values[i]
            , df.minor_xs(stock_symbol)["insurance_contract_reserves"].values[i], df.minor_xs(stock_symbol)["proxy_secu_proceeds"].values[i], df.minor_xs(stock_symbol)["receivings_from_vicariously_sold_securities"].values[i],
                 df.minor_xs(stock_symbol)["non_current_liability_in_one_year"].values[i],
             df.minor_xs(stock_symbol)["other_current_liability"].values[i], df.minor_xs(stock_symbol)["total_current_liability"].values[i], df.minor_xs(stock_symbol)["longterm_loan"].values[i],
                 df.minor_xs(stock_symbol)["bonds_payable"].values[i], df.minor_xs(stock_symbol)["longterm_account_payable"].values[i], df.minor_xs(stock_symbol)["specific_account_payable"].values[i],
                 df.minor_xs(stock_symbol)["estimate_liability"].values[i], df.minor_xs(stock_symbol)["deferred_tax_liability"].values[i], df.minor_xs(stock_symbol)["other_non_current_liability"].values[i]
            , df.minor_xs(stock_symbol)["total_non_current_liability"].values[i], df.minor_xs(stock_symbol)["total_liability"].values[i], df.minor_xs(stock_symbol)["paidin_capital"].values[i],
                 df.minor_xs(stock_symbol)["capital_reserve_fund"].values[i],
             df.minor_xs(stock_symbol)["treasury_stock"].values[i], df.minor_xs(stock_symbol)["specific_reserves"].values[i], df.minor_xs(stock_symbol)["surplus_reserve_fund"].values[i],
                 df.minor_xs(stock_symbol)["ordinary_risk_reserve_fund"].values[i], df.minor_xs(stock_symbol)["retained_profit"].values[i],
             df.minor_xs(stock_symbol)["foreign_currency_report_conv_diff"].values[i], df.minor_xs(stock_symbol)["equities_parent_company_owners"].values[i], df.minor_xs(stock_symbol)["minority_interests"].values[i],
                 df.minor_xs(stock_symbol)["total_owner_equities"].values[i], df.minor_xs(stock_symbol)["total_sheet_owner_equities"].values[i])
            data_list.append(t)
        sql = "INSERT INTO balance_cn(security_lookup_id, code, pubDate, endDate, cash_equivalents, settlement_provi,"\
                     "lend_capital, trading_assets, bill_receivable, account_receivable, advance_payment,"\
                     "insurance_receivables, reinsurance_receivables, reinsurance_contract_reserves_receivable,"\
                     "interest_receivable, dividend_receivable, other_receivable, bought_sellback_assets,"\
                     "inventories, non_current_asset_in_one_year, other_current_assets, total_current_assets,"\
                     "loan_and_advance, hold_for_sale_assets, hold_to_maturity_investments,"\
                     "longterm_receivable_account, longterm_equity_invest, investment_property, fixed_assets,"\
                     "constru_in_process, construction_materials, fixed_assets_liquidation, biological_assets,"\
                     "oil_gas_assets, intangible_assets, development_expenditure, good_will,"\
                     "long_deferred_expense, deferred_tax_assets, other_non_current_assets,"\
                     "total_non_current_assets, total_assets, shortterm_loan, borrowing_from_centralbank,"\
                     "deposit_in_interbank, borrowing_capital, trading_liability, notes_payable,"\
                     "accounts_payable, advance_peceipts, sold_buyback_secu_proceeds, commission_payable,"\
                     "salaries_payable, taxs_payable, interest_payable, dividend_payable, other_payable,"\
                     "reinsurance_payables, insurance_contract_reserves, proxy_secu_proceeds,"\
                     "receivings_from_vicariously_sold_securities, non_current_liability_in_one_year,"\
                     "other_current_liability, total_current_liability, longterm_loan, bonds_payable,"\
                     "longterm_account_payable, specific_account_payable, estimate_liability,"\
                     "deferred_tax_liability, other_non_current_liability, total_non_current_liability,"\
                     "total_liability, paidin_capital, capital_reserve_fund, treasury_stock, specific_reserves,"\
                     "surplus_reserve_fund, ordinary_risk_reserve_fund, retained_profit,"\
                     "foreign_currency_report_conv_diff, equities_parent_company_owners, minority_interests,"\
                     "total_owner_equities, total_sheet_owner_equities)"\
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code)," \
              "pubDate=VALUES(pubDate),cash_equivalents=VALUES(cash_equivalents),settlement_provi=VALUES(settlement_provi),lend_capital=VALUES(lend_capital),trading_assets=VALUES(trading_assets)," \
              "bill_receivable=VALUES(bill_receivable),account_receivable=VALUES(account_receivable),advance_payment=VALUES(advance_payment),insurance_receivables=VALUES(insurance_receivables)," \
              "reinsurance_receivables=VALUES(reinsurance_receivables),reinsurance_contract_reserves_receivable=VALUES(reinsurance_contract_reserves_receivable),interest_receivable=VALUES(interest_receivable)," \
              "dividend_receivable=VALUES(dividend_receivable),other_receivable=VALUES(other_receivable),bought_sellback_assets=VALUES(bought_sellback_assets),inventories=VALUES(inventories),non_current_asset_in_one_year=VALUES(non_current_asset_in_one_year)," \
              "other_current_assets=VALUES(other_current_assets),total_current_assets=VALUES(total_current_assets),loan_and_advance=VALUES(loan_and_advance),hold_for_sale_assets=VALUES(hold_for_sale_assets)," \
              "hold_to_maturity_investments=VALUES(hold_to_maturity_investments),longterm_receivable_account=VALUES(longterm_receivable_account),longterm_equity_invest=VALUES(longterm_equity_invest)," \
              "investment_property=VALUES(investment_property),fixed_assets=VALUES(fixed_assets),constru_in_process=VALUES(constru_in_process),construction_materials=VALUES(construction_materials),fixed_assets_liquidation=VALUES(fixed_assets_liquidation)," \
              "biological_assets=VALUES(biological_assets),oil_gas_assets=VALUES(oil_gas_assets),intangible_assets=VALUES(intangible_assets),development_expenditure=VALUES(development_expenditure)," \
              "good_will=VALUES(good_will),long_deferred_expense=VALUES(long_deferred_expense),deferred_tax_assets=VALUES(deferred_tax_assets)," \
              "other_non_current_assets=VALUES(other_non_current_assets),total_non_current_assets=VALUES(total_non_current_assets),total_assets=VALUES(total_assets),shortterm_loan=VALUES(shortterm_loan),borrowing_from_centralbank=VALUES(borrowing_from_centralbank)," \
              "deposit_in_interbank=VALUES(deposit_in_interbank),borrowing_capital=VALUES(borrowing_capital),trading_liability=VALUES(trading_liability),notes_payable=VALUES(notes_payable)," \
              "accounts_payable=VALUES(accounts_payable),advance_peceipts=VALUES(advance_peceipts),sold_buyback_secu_proceeds=VALUES(sold_buyback_secu_proceeds)," \
              "commission_payable=VALUES(commission_payable),salaries_payable=VALUES(salaries_payable),taxs_payable	=VALUES(taxs_payable),interest_payable=VALUES(interest_payable),dividend_payable=VALUES(dividend_payable)," \
              "other_payable=VALUES(other_payable),reinsurance_payables=VALUES(reinsurance_payables),insurance_contract_reserves=VALUES(insurance_contract_reserves),proxy_secu_proceeds=VALUES(proxy_secu_proceeds)," \
              "receivings_from_vicariously_sold_securities=VALUES(receivings_from_vicariously_sold_securities),non_current_liability_in_one_year=VALUES(non_current_liability_in_one_year),other_current_liability=VALUES(other_current_liability)," \
              "total_current_liability=VALUES(total_current_liability),longterm_loan=VALUES(longterm_loan),bonds_payable=VALUES(bonds_payable),longterm_account_payable=VALUES(longterm_account_payable),specific_account_payable=VALUES(specific_account_payable)," \
              "estimate_liability=VALUES(estimate_liability),deferred_tax_liability=VALUES(deferred_tax_liability),other_non_current_liability=VALUES(other_non_current_liability),total_non_current_liability=VALUES(total_non_current_liability)," \
              "total_liability=VALUES(total_liability),paidin_capital=VALUES(paidin_capital),capital_reserve_fund=VALUES(capital_reserve_fund)," \
              "treasury_stock=VALUES(treasury_stock),specific_reserves=VALUES(specific_reserves),surplus_reserve_fund=VALUES(surplus_reserve_fund),ordinary_risk_reserve_fund=VALUES(ordinary_risk_reserve_fund),retained_profit=VALUES(retained_profit)," \
              "foreign_currency_report_conv_diff=VALUES(foreign_currency_report_conv_diff),equities_parent_company_owners=VALUES(equities_parent_company_owners),minority_interests=VALUES(minority_interests),total_owner_equities=VALUES(total_owner_equities)," \
              "total_sheet_owner_equities=VALUES(total_sheet_owner_equities)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        traceback.print_exc()

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        balance
    ).filter(
        balance.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
