from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame

from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol).index[i], df.minor_xs(stock_symbol)["capitalization"].values[i] * 1e4, df.minor_xs(stock_symbol)["circulating_cap"].values[i] * 1e4, df.minor_xs(stock_symbol)["market_cap"].values[i] * 1e8
            , df.minor_xs(stock_symbol)["circulating_market_cap"].values[i] * 1e8, df.minor_xs(stock_symbol)["turnover_ratio"].values[i] / 100, df.minor_xs(stock_symbol)["pe_ratio"].values[i], df.minor_xs(stock_symbol)["pe_ratio_lyr"].values[i],
             df.minor_xs(stock_symbol)["pb_ratio"].values[i], df.minor_xs(stock_symbol)["ps_ratio"].values[i], df.minor_xs(stock_symbol)["pcf_ratio"].values[i])
            data_list.append(t)
        sql = "INSERT INTO valuation_cn(security_lookup_id, code, time_x, capitalization, circulating_cap, market_cap,circulating_market_cap, turnover_ratio, pe_ratio, pe_ratio_lyr, pb_ratio, ps_ratio,pcf_ratio)"\
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"\
                "ON DUPLICATE KEY UPDATE SECURITY_LOOKUP_ID=VALUES(SECURITY_LOOKUP_ID)," \
              "code=VALUES(code),time_x=VALUES(time_x),capitalization=VALUES(capitalization),circulating_cap=VALUES(circulating_cap),market_cap=VALUES(market_cap)," \
              "circulating_market_cap=VALUES(circulating_market_cap),turnover_ratio=VALUES(turnover_ratio),pe_ratio=VALUES(pe_ratio),pe_ratio_lyr=VALUES(pe_ratio_lyr)," \
              "pb_ratio=VALUES(pb_ratio),ps_ratio=VALUES(ps_ratio),pcf_ratio=VALUES(pcf_ratio)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except:
        print(stock_symbol + " error")

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        valuation
    ).filter(
        valuation.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
