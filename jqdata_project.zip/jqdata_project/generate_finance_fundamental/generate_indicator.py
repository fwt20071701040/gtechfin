from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["eps"].values[i],
                 df.minor_xs(stock_symbol)["adjusted_profit"].values[i]
            , df.minor_xs(stock_symbol)["operating_profit"].values[i], df.minor_xs(stock_symbol)["value_change_profit"].values[i], df.minor_xs(stock_symbol)["roe"].values[i] / 100,
                 df.minor_xs(stock_symbol)["inc_return"].values[i] / 100,df.minor_xs(stock_symbol)["roa"].values[i] / 100, df.minor_xs(stock_symbol)["net_profit_margin"].values[i] / 100,
                 df.minor_xs(stock_symbol)["gross_profit_margin"].values[i] / 100,
            df.minor_xs(stock_symbol)["expense_to_total_revenue"].values[i] / 100, df.minor_xs(stock_symbol)["operation_profit_to_total_revenue"].values[i] / 100, df.minor_xs(stock_symbol)["net_profit_to_total_revenue"].values[i] / 100,
                 df.minor_xs(stock_symbol)["operating_expense_to_total_revenue"].values[i] / 100,df.minor_xs(stock_symbol)["ga_expense_to_total_revenue"].values[i] / 100,
                 df.minor_xs(stock_symbol)["financing_expense_to_total_revenue"].values[i] / 100,df.minor_xs(stock_symbol)["operating_profit_to_profit"].values[i] / 100, df.minor_xs(stock_symbol)["invesment_profit_to_profit"].values[i] / 100,
                 df.minor_xs(stock_symbol)["adjusted_profit_to_profit"].values[i] / 100
            , df.minor_xs(stock_symbol)["goods_sale_and_service_to_revenue"].values[i] / 100, df.minor_xs(stock_symbol)["ocf_to_revenue"].values[i] / 100, df.minor_xs(stock_symbol)["ocf_to_operating_profit"].values[i] / 100,
                 df.minor_xs(stock_symbol)["inc_total_revenue_year_on_year"].values[i] / 100,
             df.minor_xs(stock_symbol)["inc_total_revenue_annual"].values[i] / 100, df.minor_xs(stock_symbol)["inc_revenue_year_on_year"].values[i] / 100, df.minor_xs(stock_symbol)["inc_revenue_annual"].values[i] / 100,
                 df.minor_xs(stock_symbol)["inc_operation_profit_year_on_year"].values[i] / 100, df.minor_xs(stock_symbol)["inc_operation_profit_annual"].values[i] / 100, df.minor_xs(stock_symbol)["inc_net_profit_year_on_year"].values[i] / 100,
                 df.minor_xs(stock_symbol)["inc_net_profit_annual"].values[i] / 100, df.minor_xs(stock_symbol)["inc_net_profit_to_shareholders_year_on_year"].values[i] / 100, df.minor_xs(stock_symbol)["inc_net_profit_to_shareholders_annual"].values[i] / 100)
            data_list.append(t)
        sql = "INSERT INTO indicator_cn(security_lookup_id, code, pubDate, endDate, eps, adjusted_profit,"\
                       "operating_profit, value_change_profit, roe, inc_return, roa, net_profit_margin,"\
                       "gross_profit_margin, expense_to_total_revenue, operation_profit_to_total_revenue,"\
                       "net_profit_to_total_revenue, operating_expense_to_total_revenue,"\
                       "ga_expense_to_total_revenue, financing_expense_to_total_revenue,"\
                       "operating_profit_to_profit, invesment_profit_to_profit, adjusted_profit_to_profit,"\
                       "goods_sale_and_service_to_revenue, ocf_to_revenue, ocf_to_operating_profit,"\
                       "inc_total_revenue_year_on_year, inc_total_revenue_annual, inc_revenue_year_on_year,"\
                       "inc_revenue_annual, inc_operation_profit_year_on_year, inc_operation_profit_annual,"\
                       "inc_net_profit_year_on_year, inc_net_profit_annual,"\
                       "inc_net_profit_to_shareholders_year_on_year, inc_net_profit_to_shareholders_annual)"\
                "VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
                        "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code), pubDate=VALUES(pubDate), eps=VALUES(eps), adjusted_profit=VALUES(adjusted_profit),"\
                       "operating_profit=VALUES(operating_profit), value_change_profit=VALUES(value_change_profit), roe=VALUES(roe), inc_return=VALUES(inc_return), roa=VALUES(roa), net_profit_margin=VALUES(net_profit_margin),"\
                       "gross_profit_margin=VALUES(gross_profit_margin), expense_to_total_revenue=VALUES(expense_to_total_revenue), operation_profit_to_total_revenue=VALUES(operation_profit_to_total_revenue),"\
                       "net_profit_to_total_revenue=VALUES(net_profit_to_total_revenue), operating_expense_to_total_revenue=VALUES(operating_expense_to_total_revenue),"\
                       "ga_expense_to_total_revenue=VALUES(ga_expense_to_total_revenue), financing_expense_to_total_revenue=VALUES(financing_expense_to_total_revenue),"\
                       "operating_profit_to_profit=VALUES(operating_profit_to_profit), invesment_profit_to_profit=VALUES(invesment_profit_to_profit), adjusted_profit_to_profit=VALUES(adjusted_profit_to_profit),"\
                       "goods_sale_and_service_to_revenue=VALUES(goods_sale_and_service_to_revenue), ocf_to_revenue=VALUES(ocf_to_revenue), ocf_to_operating_profit=VALUES(ocf_to_operating_profit),"\
                       "inc_total_revenue_year_on_year=VALUES(inc_total_revenue_year_on_year), inc_total_revenue_annual=VALUES(inc_total_revenue_annual), inc_revenue_year_on_year=VALUES(inc_revenue_year_on_year),"\
                       "inc_revenue_annual=VALUES(inc_revenue_annual), inc_operation_profit_year_on_year=VALUES(inc_operation_profit_year_on_year), inc_operation_profit_annual=VALUES(inc_operation_profit_annual),"\
                       "inc_net_profit_year_on_year=VALUES(inc_net_profit_year_on_year), inc_net_profit_annual=VALUES(inc_net_profit_annual),"\
                       "inc_net_profit_to_shareholders_year_on_year=VALUES(inc_net_profit_to_shareholders_year_on_year), inc_net_profit_to_shareholders_annual=VALUES(inc_net_profit_to_shareholders_annual)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        traceback.print_exc()

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        indicator
    ).filter(
        indicator.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
