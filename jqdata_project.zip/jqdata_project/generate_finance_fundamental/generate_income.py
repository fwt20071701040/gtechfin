from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["total_operating_revenue"].values[i],
                 df.minor_xs(stock_symbol)["operating_revenue"].values[i]
            , df.minor_xs(stock_symbol)["interest_income"].values[i], df.minor_xs(stock_symbol)["premiums_earned"].values[i], df.minor_xs(stock_symbol)["commission_income"].values[i],
                 df.minor_xs(stock_symbol)["total_operating_cost"].values[i],df.minor_xs(stock_symbol)["operating_cost"].values[i], df.minor_xs(stock_symbol)["interest_expense"].values[i],
                 df.minor_xs(stock_symbol)["commission_expense"].values[i],
            df.minor_xs(stock_symbol)["refunded_premiums"].values[i], df.minor_xs(stock_symbol)["net_pay_insurance_claims"].values[i], df.minor_xs(stock_symbol)["withdraw_insurance_contract_reserve"].values[i],
                 df.minor_xs(stock_symbol)["policy_dividend_payout"].values[i], df.minor_xs(stock_symbol)["reinsurance_cost"].values[i], df.minor_xs(stock_symbol)["operating_tax_surcharges"].values[i]
            , df.minor_xs(stock_symbol)["sale_expense"].values[i], df.minor_xs(stock_symbol)["administration_expense"].values[i], df.minor_xs(stock_symbol)["financial_expense"].values[i],
                 df.minor_xs(stock_symbol)["asset_impairment_loss"].values[i],
             df.minor_xs(stock_symbol)["fair_value_variable_income"].values[i], df.minor_xs(stock_symbol)["investment_income"].values[i], df.minor_xs(stock_symbol)["invest_income_associates"].values[i],
                 df.minor_xs(stock_symbol)["exchange_income"].values[i], df.minor_xs(stock_symbol)["operating_profit"].values[i], df.minor_xs(stock_symbol)["non_operating_revenue"].values[i],
                 df.minor_xs(stock_symbol)["non_operating_expense"].values[i], df.minor_xs(stock_symbol)["disposal_loss_non_current_liability"].values[i], df.minor_xs(stock_symbol)["total_profit"].values[i]
            , df.minor_xs(stock_symbol)["income_tax_expense"].values[i], df.minor_xs(stock_symbol)["net_profit"].values[i], df.minor_xs(stock_symbol)["np_parent_company_owners"].values[i],
                 df.minor_xs(stock_symbol)["minority_profit"].values[i],
             df.minor_xs(stock_symbol)["basic_eps"].values[i], df.minor_xs(stock_symbol)["diluted_eps"].values[i], df.minor_xs(stock_symbol)["other_composite_income"].values[i],
                 df.minor_xs(stock_symbol)["total_composite_income"].values[i], df.minor_xs(stock_symbol)["ci_parent_company_owners"].values[i], df.minor_xs(stock_symbol)["ci_minority_owners"].values[i])
            data_list.append(t)
        sql = "INSERT INTO income_cn(security_lookup_id, code, pubDate, endDate, total_operating_revenue, operating_revenue,"\
                    "interest_income, premiums_earned, commission_income, total_operating_cost, operating_cost,"\
                    "interest_expense, commission_expense, refunded_premiums, net_pay_insurance_claims,"\
                    "withdraw_insurance_contract_reserve, policy_dividend_payout, reinsurance_cost,"\
                    "operating_tax_surcharges, sale_expense, administration_expense, financial_expense,"\
                    "asset_impairment_loss, fair_value_variable_income, investment_income,"\
                    "invest_income_associates, exchange_income, operating_profit, non_operating_revenue,"\
                    "non_operating_expense, disposal_loss_non_current_liability, total_profit,"\
                    "income_tax_expense, net_profit, np_parent_company_owners, minority_profit, basic_eps,"\
                    "diluted_eps, other_composite_income, total_composite_income, ci_parent_company_owners,"\
                    "ci_minority_owners)"\
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code), pubDate=VALUES(pubDate), total_operating_revenue=VALUES(total_operating_revenue), operating_revenue=VALUES(operating_revenue),"\
                    "interest_income=VALUES(interest_income), premiums_earned=VALUES(premiums_earned), commission_income=VALUES(commission_income), total_operating_cost=VALUES(total_operating_cost), operating_cost=VALUES(operating_cost),"\
                    "interest_expense=VALUES(interest_expense), commission_expense=VALUES(commission_expense), refunded_premiums=VALUES(refunded_premiums), net_pay_insurance_claims=VALUES(net_pay_insurance_claims),"\
                    "withdraw_insurance_contract_reserve=VALUES(withdraw_insurance_contract_reserve), policy_dividend_payout=VALUES(policy_dividend_payout), reinsurance_cost=VALUES(reinsurance_cost),"\
                    "operating_tax_surcharges=VALUES(operating_tax_surcharges), sale_expense=VALUES(sale_expense), administration_expense=VALUES(administration_expense), financial_expense=VALUES(financial_expense),"\
                    "asset_impairment_loss=VALUES(asset_impairment_loss), fair_value_variable_income=VALUES(fair_value_variable_income), investment_income=VALUES(investment_income),"\
                    "invest_income_associates=VALUES(invest_income_associates), exchange_income=VALUES(exchange_income), operating_profit=VALUES(operating_profit), non_operating_revenue=VALUES(non_operating_revenue),"\
                    "non_operating_expense=VALUES(non_operating_expense), disposal_loss_non_current_liability=VALUES(disposal_loss_non_current_liability), total_profit=VALUES(total_profit),"\
                    "income_tax_expense=VALUES(income_tax_expense), net_profit=VALUES(net_profit), np_parent_company_owners=VALUES(np_parent_company_owners), minority_profit=VALUES(minority_profit), basic_eps=VALUES(basic_eps),"\
                    "diluted_eps=VALUES(diluted_eps), other_composite_income=VALUES(other_composite_income), total_composite_income=VALUES(total_composite_income), ci_parent_company_owners=VALUES(ci_parent_company_owners),"\
                    "ci_minority_owners=VALUES(ci_minority_owners)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        traceback.print_exc()

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        income
    ).filter(
        income.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
