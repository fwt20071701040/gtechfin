from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["total_loan"].values[i],
                 df.minor_xs(stock_symbol)["total_deposit"].values[i]
            , df.minor_xs(stock_symbol)["interest_earning_assets"].values[i], df.minor_xs(stock_symbol)["non_interest_earning_assets"].values[i], df.minor_xs(stock_symbol)["interest_earning_assets_yield"].values[i],
                 df.minor_xs(stock_symbol)["interest_bearing_liabilities"].values[i],df.minor_xs(stock_symbol)["non_interest_bearing_liabilities"].values[i], df.minor_xs(stock_symbol)["interest_bearing_liabilities_interest_rate"].values[i],
                 df.minor_xs(stock_symbol)["non_interest_income"].values[i],
            df.minor_xs(stock_symbol)["non_interest_income_ratio"].values[i], df.minor_xs(stock_symbol)["net_interest_margin"].values[i], df.minor_xs(stock_symbol)["net_profit_margin"].values[i],
                 df.minor_xs(stock_symbol)["core_level_capital"].values[i], df.minor_xs(stock_symbol)["net_core_level_capital"].values[i], df.minor_xs(stock_symbol)["core_level_capital_adequacy_ratio"].values[i]
            , df.minor_xs(stock_symbol)["net_level_1_capital"].values[i], df.minor_xs(stock_symbol)["level_1_capital_adequacy_ratio"].values[i], df.minor_xs(stock_symbol)["net_capital"].values[i],
                 df.minor_xs(stock_symbol)["capital_adequacy_ratio"].values[i],
             df.minor_xs(stock_symbol)["weighted_risky_asset"].values[i], df.minor_xs(stock_symbol)["deposit_loan_ratio"].values[i], df.minor_xs(stock_symbol)["short_term_asset_liquidity_ratio_CNY"].values[i],
                 df.minor_xs(stock_symbol)["short_term_asset_liquidity_ratio_FC"].values[i], df.minor_xs(stock_symbol)["Nonperforming_loan_rate"].values[i], df.minor_xs(stock_symbol)["single_largest_customer_loan_ratio"].values[i],
                 df.minor_xs(stock_symbol)["top_ten_customer_loan_ratio"].values[i], df.minor_xs(stock_symbol)["bad_debts_reserve"].values[i], df.minor_xs(stock_symbol)["non_performing_loan_provision_coverage"].values[i]
            , df.minor_xs(stock_symbol)["cost_to_income_ratio"].values[i], df.minor_xs(stock_symbol)["former_core_capital"].values[i], df.minor_xs(stock_symbol)["former_net_core_capital"].values[i],
                 df.minor_xs(stock_symbol)["former_net_core_capital_adequacy_ratio"].values[i],
             df.minor_xs(stock_symbol)["former_net_capital"].values[i], df.minor_xs(stock_symbol)["former_capital_adequacy_ratio"].values[i], df.minor_xs(stock_symbol)["former_weighted_risky_asset"].values[i],
                 df.minor_xs(stock_symbol)["normal_amount"].values[i], df.minor_xs(stock_symbol)["normal_amount_ratio"].values[i] / 100, df.minor_xs(stock_symbol)["concerned_amount"].values[i],
                 df.minor_xs(stock_symbol)["concerned_amount_ratio"].values[i] / 100, df.minor_xs(stock_symbol)["secondary_amount"].values[i], df.minor_xs(stock_symbol)["secondary_amount_ratio"].values[i] / 100
            , df.minor_xs(stock_symbol)["suspicious_amount"].values[i], df.minor_xs(stock_symbol)["suspicious_amount_ratio"].values[i] / 100, df.minor_xs(stock_symbol)["loss_amount"].values[i],
                 df.minor_xs(stock_symbol)["loss_amount_ratio"].values[i],
             df.minor_xs(stock_symbol)["short_term_loan_average_balance"].values[i], df.minor_xs(stock_symbol)["short_term_loan_annualized_average_interest_rate"].values[i], df.minor_xs(stock_symbol)["mid_term_loan_annualized_average_balance"].values[i],
                 df.minor_xs(stock_symbol)["mid_term_loan_annualized_average_interest_rate"].values[i], df.minor_xs(stock_symbol)["enterprise_deposits_average_balance"].values[i], df.minor_xs(stock_symbol)["enterprise_deposits_average_interest_rate"].values[i],
                 df.minor_xs(stock_symbol)["savings_deposit_average_balance"].values[i], df.minor_xs(stock_symbol)["savings_deposit_average_interest_rate"].values[i])
            data_list.append(t)
        sql = "INSERT INTO bank_indicator_cn(security_lookup_id, code, pubDate, endDate, total_loan, total_deposit,"\
                            "interest_earning_assets, non_interest_earning_assets, interest_earning_assets_yield,"\
                            "interest_bearing_liabilities, non_interest_bearing_liabilities,"\
                            "interest_bearing_liabilities_interest_rate, non_interest_income,"\
                            "non_interest_income_ratio, net_interest_margin, net_profit_margin,"\
                            "core_level_capital, net_core_level_capital, core_level_capital_adequacy_ratio,"\
                            "net_level_1_capital, level_1_capital_adequacy_ratio, net_capital,"\
                            "capital_adequacy_ratio, weighted_risky_asset, deposit_loan_ratio,"\
                            "short_term_asset_liquidity_ratio_CNY, short_term_asset_liquidity_ratio_FC,"\
                            "Nonperforming_loan_rate, single_largest_customer_loan_ratio,"\
                            "top_ten_customer_loan_ratio, bad_debts_reserve,"\
                            "non_performing_loan_provision_coverage, cost_to_income_ratio, former_core_capital,"\
                            "former_net_core_capital, former_net_core_capital_adequacy_ratio, former_net_capital,"\
                            "former_capital_adequacy_ratio, former_weighted_risky_asset, normal_amount,"\
                            "normal_amount_ratio, concerned_amount, concerned_amount_ratio, secondary_amount,"\
                            "secondary_amount_ratio, suspicious_amount, suspicious_amount_ratio, loss_amount,"\
                            "loss_amount_ratio, short_term_loan_average_balance,"\
                            "short_term_loan_annualized_average_interest_rate,"\
                            "mid_term_loan_annualized_average_balance,"\
                            "mid_term_loan_annualized_average_interest_rate, enterprise_deposits_average_balance,"\
                            "enterprise_deposits_average_interest_rate, savings_deposit_average_balance,"\
                            "savings_deposit_average_interest_rate)"\
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code), pubDate=VALUES(pubDate), total_loan=VALUES(total_loan), total_deposit=VALUES(total_deposit),"\
                            "interest_earning_assets=VALUES(interest_earning_assets), non_interest_earning_assets=VALUES(non_interest_earning_assets), interest_earning_assets_yield=VALUES(interest_earning_assets_yield),"\
                            "interest_bearing_liabilities=VALUES(interest_bearing_liabilities), non_interest_bearing_liabilities=VALUES(non_interest_bearing_liabilities),"\
                            "interest_bearing_liabilities_interest_rate=VALUES(interest_bearing_liabilities_interest_rate), non_interest_income=VALUES(non_interest_income),"\
                            "non_interest_income_ratio=VALUES(non_interest_income_ratio), net_interest_margin=VALUES(net_interest_margin), net_profit_margin=VALUES(net_profit_margin),"\
                            "core_level_capital=VALUES(core_level_capital), net_core_level_capital=VALUES(net_core_level_capital), core_level_capital_adequacy_ratio=VALUES(core_level_capital_adequacy_ratio),"\
                            "net_level_1_capital=VALUES(net_level_1_capital), level_1_capital_adequacy_ratio=VALUES(level_1_capital_adequacy_ratio), net_capital=VALUES(net_capital),"\
                            "capital_adequacy_ratio=VALUES(capital_adequacy_ratio), weighted_risky_asset=VALUES(weighted_risky_asset), deposit_loan_ratio=VALUES(deposit_loan_ratio),"\
                            "short_term_asset_liquidity_ratio_CNY=VALUES(short_term_asset_liquidity_ratio_CNY), short_term_asset_liquidity_ratio_FC=VALUES(short_term_asset_liquidity_ratio_FC),"\
                            "Nonperforming_loan_rate=VALUES(Nonperforming_loan_rate), single_largest_customer_loan_ratio=VALUES(single_largest_customer_loan_ratio),"\
                            "top_ten_customer_loan_ratio=VALUES(top_ten_customer_loan_ratio), bad_debts_reserve=VALUES(bad_debts_reserve),"\
                            "non_performing_loan_provision_coverage=VALUES(non_performing_loan_provision_coverage), cost_to_income_ratio=VALUES(cost_to_income_ratio), former_core_capital=VALUES(former_core_capital),"\
                            "former_net_core_capital=VALUES(former_net_core_capital), former_net_core_capital_adequacy_ratio=VALUES(former_net_core_capital_adequacy_ratio), former_net_capital=VALUES(former_net_capital),"\
                            "former_capital_adequacy_ratio=VALUES(former_capital_adequacy_ratio), former_weighted_risky_asset=VALUES(former_weighted_risky_asset), normal_amount=VALUES(normal_amount),"\
                            "normal_amount_ratio=VALUES(normal_amount_ratio), concerned_amount=VALUES(concerned_amount), concerned_amount_ratio=VALUES(concerned_amount_ratio), secondary_amount=VALUES(secondary_amount),"\
                            "secondary_amount_ratio=VALUES(secondary_amount_ratio), suspicious_amount=VALUES(suspicious_amount), suspicious_amount_ratio=VALUES(suspicious_amount_ratio), loss_amount=VALUES(loss_amount),"\
                            "loss_amount_ratio=VALUES(loss_amount_ratio), short_term_loan_average_balance=VALUES(short_term_loan_average_balance),"\
                            "short_term_loan_annualized_average_interest_rate=VALUES(short_term_loan_annualized_average_interest_rate),"\
                            "mid_term_loan_annualized_average_balance=VALUES(mid_term_loan_annualized_average_balance),"\
                            "mid_term_loan_annualized_average_interest_rate=VALUES(mid_term_loan_annualized_average_interest_rate), enterprise_deposits_average_balance=VALUES(enterprise_deposits_average_balance),"\
                            "enterprise_deposits_average_interest_rate=VALUES(enterprise_deposits_average_interest_rate), savings_deposit_average_balance=VALUES(savings_deposit_average_balance),"\
                            "savings_deposit_average_interest_rate=VALUES(savings_deposit_average_interest_rate)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        print(repr(e))

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    industry = get_industry(stock_symbol, date=now1)
    try:
        if "银行II" != industry[stock_symbol]["sw_l2"]["industry_name"]:
            continue
    except KeyError:
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " don't in sw_l2")
        continue
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        bank_indicator
    ).filter(
        bank_indicator.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
