from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["net_capital"].values[i],
                 df.minor_xs(stock_symbol)["net_assets"].values[i]
            , df.minor_xs(stock_symbol)["net_capital_to_reserve"].values[i], df.minor_xs(stock_symbol)["net_capital_to_net_asset"].values[i], df.minor_xs(stock_symbol)["net_capital_to_debt"].values[i],
                 df.minor_xs(stock_symbol)["net_asset_to_debt"].values[i],df.minor_xs(stock_symbol)["net_capital_to_sales_department_number"].values[i], df.minor_xs(stock_symbol)["own_stock_to_net_capital"].values[i],
                 df.minor_xs(stock_symbol)["own_security_to_net_capital"].values[i],
            df.minor_xs(stock_symbol)["operational_risk_reserve"].values[i], df.minor_xs(stock_symbol)["broker_risk_reserve"].values[i], df.minor_xs(stock_symbol)["own_security_risk_reserve"].values[i],
                 df.minor_xs(stock_symbol)["security_underwriting_reserve"].values[i],df.minor_xs(stock_symbol)["asset_management_reserve"].values[i],
                 df.minor_xs(stock_symbol)["own_equity_derivatives_to_net_capital"].values[i],df.minor_xs(stock_symbol)["own_fixed_income_to_net_capital"].values[i], df.minor_xs(stock_symbol)["margin_trading_reserve"].values[i],
                 df.minor_xs(stock_symbol)["branch_risk_reserve"].values[i]
                 )
            data_list.append(t)
        sql = "INSERT INTO security_indicator_cn(security_lookup_id, code, pubDate, endDate, net_capital, net_assets,"\
                                "net_capital_to_reserve, net_capital_to_net_asset, net_capital_to_debt,"\
                                "net_asset_to_debt, net_capital_to_sales_department_number,"\
                                "own_stock_to_net_capital, own_security_to_net_capital, operational_risk_reserve,"\
                                "broker_risk_reserve, own_security_risk_reserve, security_underwriting_reserve,"\
                                "asset_management_reserve, own_equity_derivatives_to_net_capital,"\
                                "own_fixed_income_to_net_capital, margin_trading_reserve, branch_risk_reserve)"\
                "VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code), pubDate=VALUES(pubDate), net_capital=VALUES(net_capital), net_assets=VALUES(net_assets),"\
                                "net_capital_to_reserve=VALUES(net_capital_to_reserve), net_capital_to_net_asset=VALUES(net_capital_to_net_asset), net_capital_to_debt=VALUES(net_capital_to_debt),"\
                                "net_asset_to_debt=VALUES(net_asset_to_debt), net_capital_to_sales_department_number=VALUES(net_capital_to_sales_department_number),"\
                                "own_stock_to_net_capital=VALUES(own_stock_to_net_capital), own_security_to_net_capital=VALUES(own_security_to_net_capital), operational_risk_reserve=VALUES(operational_risk_reserve),"\
                                "broker_risk_reserve=VALUES(broker_risk_reserve), own_security_risk_reserve=VALUES(own_security_risk_reserve), security_underwriting_reserve=VALUES(security_underwriting_reserve),"\
                                "asset_management_reserve=VALUES(asset_management_reserve), own_equity_derivatives_to_net_capital=VALUES(own_equity_derivatives_to_net_capital),"\
                                "own_fixed_income_to_net_capital=VALUES(own_fixed_income_to_net_capital), margin_trading_reserve=VALUES(margin_trading_reserve), branch_risk_reserve=VALUES(branch_risk_reserve)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        print(get_security_info(stock_symbol).display_name + repr(e))

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    industry = get_industry(stock_symbol, date=now1)
    try:
        if "证券II" != industry[stock_symbol]["sw_l2"]["industry_name"]:
            continue
    except KeyError:
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " don't in sw_l2")
        continue
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        security_indicator
    ).filter(
        security_indicator.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
