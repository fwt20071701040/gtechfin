from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["goods_sale_and_service_render_cash"].values[i],
                 df.minor_xs(stock_symbol)["net_deposit_increase"].values[i]
            , df.minor_xs(stock_symbol)["net_borrowing_from_central_bank"].values[i], df.minor_xs(stock_symbol)["net_borrowing_from_finance_co"].values[i], df.minor_xs(stock_symbol)["net_original_insurance_cash"].values[i],
                 df.minor_xs(stock_symbol)["net_cash_received_from_reinsurance_business"].values[i],df.minor_xs(stock_symbol)["net_insurer_deposit_investment"].values[i], df.minor_xs(stock_symbol)["net_deal_trading_assets"].values[i],
                 df.minor_xs(stock_symbol)["interest_and_commission_cashin"].values[i],
            df.minor_xs(stock_symbol)["net_increase_in_placements"].values[i], df.minor_xs(stock_symbol)["net_buyback"].values[i], df.minor_xs(stock_symbol)["tax_levy_refund"].values[i],
                 df.minor_xs(stock_symbol)["other_cashin_related_operate"].values[i], df.minor_xs(stock_symbol)["subtotal_operate_cash_inflow"].values[i], df.minor_xs(stock_symbol)["goods_and_services_cash_paid"].values[i]
            , df.minor_xs(stock_symbol)["net_loan_and_advance_increase"].values[i], df.minor_xs(stock_symbol)["net_deposit_in_cb_and_ib"].values[i], df.minor_xs(stock_symbol)["original_compensation_paid"].values[i],
                 df.minor_xs(stock_symbol)["handling_charges_and_commission"].values[i],
             df.minor_xs(stock_symbol)["policy_dividend_cash_paid"].values[i], df.minor_xs(stock_symbol)["staff_behalf_paid"].values[i], df.minor_xs(stock_symbol)["tax_payments"].values[i],
                 df.minor_xs(stock_symbol)["other_operate_cash_paid"].values[i], df.minor_xs(stock_symbol)["subtotal_operate_cash_outflow"].values[i], df.minor_xs(stock_symbol)["net_operate_cash_flow"].values[i],
                 df.minor_xs(stock_symbol)["invest_withdrawal_cash"].values[i], df.minor_xs(stock_symbol)["invest_proceeds"].values[i], df.minor_xs(stock_symbol)["fix_intan_other_asset_dispo_cash"].values[i]
            , df.minor_xs(stock_symbol)["net_cash_deal_subcompany"].values[i], df.minor_xs(stock_symbol)["other_cash_from_invest_act"].values[i], df.minor_xs(stock_symbol)["subtotal_invest_cash_inflow"].values[i],
                 df.minor_xs(stock_symbol)["fix_intan_other_asset_acqui_cash"].values[i],
             df.minor_xs(stock_symbol)["invest_cash_paid"].values[i], df.minor_xs(stock_symbol)["impawned_loan_net_increase"].values[i], df.minor_xs(stock_symbol)["net_cash_from_sub_company"].values[i],
                 df.minor_xs(stock_symbol)["other_cash_to_invest_act"].values[i], df.minor_xs(stock_symbol)["subtotal_invest_cash_outflow"].values[i], df.minor_xs(stock_symbol)["net_invest_cash_flow"].values[i],
                 df.minor_xs(stock_symbol)["cash_from_invest"].values[i], df.minor_xs(stock_symbol)["cash_from_mino_s_invest_sub"].values[i], df.minor_xs(stock_symbol)["cash_from_borrowing"].values[i]
            , df.minor_xs(stock_symbol)["cash_from_bonds_issue"].values[i], df.minor_xs(stock_symbol)["other_finance_act_cash"].values[i], df.minor_xs(stock_symbol)["subtotal_finance_cash_inflow"].values[i],
                 df.minor_xs(stock_symbol)["borrowing_repayment"].values[i],
             df.minor_xs(stock_symbol)["dividend_interest_payment"].values[i], df.minor_xs(stock_symbol)["proceeds_from_sub_to_mino_s"].values[i], df.minor_xs(stock_symbol)["other_finance_act_payment"].values[i],
                 df.minor_xs(stock_symbol)["subtotal_finance_cash_outflow"].values[i], df.minor_xs(stock_symbol)["net_finance_cash_flow"].values[i], df.minor_xs(stock_symbol)["exchange_rate_change_effect"].values[i],
                 df.minor_xs(stock_symbol)["cash_equivalent_increase"].values[i], df.minor_xs(stock_symbol)["cash_equivalents_at_beginning"].values[i], df.minor_xs(stock_symbol)["cash_and_equivalents_at_end"].values[i])
            data_list.append(t)
        sql = "INSERT INTO cash_flow_cn(security_lookup_id, code, pubDate, endDate, goods_sale_and_service_render_cash,"\
                       "net_deposit_increase, net_borrowing_from_central_bank, net_borrowing_from_finance_co,"\
                       "net_original_insurance_cash, net_cash_received_from_reinsurance_business,"\
                       "net_insurer_deposit_investment, net_deal_trading_assets, interest_and_commission_cashin,"\
                       "net_increase_in_placements, net_buyback, tax_levy_refund, other_cashin_related_operate,"\
                       "subtotal_operate_cash_inflow, goods_and_services_cash_paid, net_loan_and_advance_increase,"\
                       "net_deposit_in_cb_and_ib, original_compensation_paid, handling_charges_and_commission,"\
                       "policy_dividend_cash_paid, staff_behalf_paid, tax_payments, other_operate_cash_paid,"\
                       "subtotal_operate_cash_outflow, net_operate_cash_flow, invest_withdrawal_cash,"\
                       "invest_proceeds, fix_intan_other_asset_dispo_cash, net_cash_deal_subcompany,"\
                       "other_cash_from_invest_act, subtotal_invest_cash_inflow, fix_intan_other_asset_acqui_cash,"\
                       "invest_cash_paid, impawned_loan_net_increase, net_cash_from_sub_company,"\
                       "other_cash_to_invest_act, subtotal_invest_cash_outflow, net_invest_cash_flow,"\
                       "cash_from_invest, cash_from_mino_s_invest_sub, cash_from_borrowing,"\
                       "cash_from_bonds_issue, other_finance_act_cash, subtotal_finance_cash_inflow,"\
                       "borrowing_repayment, dividend_interest_payment, proceeds_from_sub_to_mino_s,"\
                       "other_finance_act_payment, subtotal_finance_cash_outflow, net_finance_cash_flow,"\
                       "exchange_rate_change_effect, cash_equivalent_increase, cash_equivalents_at_beginning,"\
                       "cash_and_equivalents_at_end)"\
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s, %s, %s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code),"\
              "pubDate=VALUES(pubDate),goods_sale_and_service_render_cash=VALUES(goods_sale_and_service_render_cash),"\
               "net_deposit_increase=VALUES(net_deposit_increase), net_borrowing_from_central_bank=VALUES(net_borrowing_from_central_bank), net_borrowing_from_finance_co=VALUES(net_borrowing_from_finance_co),"\
               "net_original_insurance_cash=VALUES(net_original_insurance_cash), net_cash_received_from_reinsurance_business=VALUES(net_cash_received_from_reinsurance_business),"\
               "net_insurer_deposit_investment=VALUES(net_insurer_deposit_investment), net_deal_trading_assets=VALUES(net_deal_trading_assets), interest_and_commission_cashin=VALUES(interest_and_commission_cashin),"\
               "net_increase_in_placements=VALUES(net_increase_in_placements), net_buyback=VALUES(net_buyback), tax_levy_refund=VALUES(tax_levy_refund), other_cashin_related_operate=VALUES(other_cashin_related_operate),"\
               "subtotal_operate_cash_inflow=VALUES(subtotal_operate_cash_inflow), goods_and_services_cash_paid=VALUES(goods_and_services_cash_paid), net_loan_and_advance_increase=VALUES(net_loan_and_advance_increase)," \
               "net_deposit_in_cb_and_ib=VALUES(net_deposit_in_cb_and_ib), original_compensation_paid=VALUES(original_compensation_paid), handling_charges_and_commission=VALUES(handling_charges_and_commission),"\
               "policy_dividend_cash_paid=VALUES(policy_dividend_cash_paid), staff_behalf_paid=VALUES(staff_behalf_paid), tax_payments=VALUES(tax_payments), other_operate_cash_paid=VALUES(other_operate_cash_paid),"\
               "subtotal_operate_cash_outflow=VALUES(subtotal_operate_cash_outflow), net_operate_cash_flow=VALUES(net_operate_cash_flow), invest_withdrawal_cash=VALUES(invest_withdrawal_cash),"\
               "invest_proceeds=VALUES(invest_proceeds), fix_intan_other_asset_dispo_cash=VALUES(fix_intan_other_asset_dispo_cash), net_cash_deal_subcompany=VALUES(net_cash_deal_subcompany),"\
               "other_cash_from_invest_act=VALUES(other_cash_from_invest_act), subtotal_invest_cash_inflow=VALUES(subtotal_invest_cash_inflow), fix_intan_other_asset_acqui_cash=VALUES(fix_intan_other_asset_acqui_cash),"\
               "invest_cash_paid=VALUES(invest_cash_paid), impawned_loan_net_increase=VALUES(impawned_loan_net_increase), net_cash_from_sub_company=VALUES(net_cash_from_sub_company),"\
               "other_cash_to_invest_act=VALUES(other_cash_to_invest_act), subtotal_invest_cash_outflow=VALUES(subtotal_invest_cash_outflow), net_invest_cash_flow=VALUES(net_invest_cash_flow),"\
               "cash_from_invest=VALUES(cash_from_invest), cash_from_mino_s_invest_sub=VALUES(cash_from_mino_s_invest_sub), cash_from_borrowing=VALUES(cash_from_borrowing),"\
               "cash_from_bonds_issue=VALUES(cash_from_bonds_issue), other_finance_act_cash=VALUES(other_finance_act_cash), subtotal_finance_cash_inflow=VALUES(subtotal_finance_cash_inflow),"\
               "borrowing_repayment=VALUES(borrowing_repayment), dividend_interest_payment=VALUES(dividend_interest_payment), proceeds_from_sub_to_mino_s=VALUES(proceeds_from_sub_to_mino_s),"\
               "other_finance_act_payment=VALUES(other_finance_act_payment), subtotal_finance_cash_outflow=VALUES(subtotal_finance_cash_outflow), net_finance_cash_flow=VALUES(net_finance_cash_flow),"\
               "exchange_rate_change_effect=VALUES(exchange_rate_change_effect), cash_equivalent_increase=VALUES(cash_equivalent_increase), cash_equivalents_at_beginning=VALUES(cash_equivalents_at_beginning),"\
               "cash_and_equivalents_at_end=VALUES(cash_and_equivalents_at_end)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        traceback.print_exc()

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        cash_flow
    ).filter(
        cash_flow.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
