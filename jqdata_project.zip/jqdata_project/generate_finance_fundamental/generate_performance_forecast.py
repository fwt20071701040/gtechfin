from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, df.minor_xs(stock_symbol)["company_id"].values[i], code_num, df.minor_xs(stock_symbol)["name"].values[i], df.minor_xs(stock_symbol)["end_date"].values[i], df.minor_xs(stock_symbol)["report_type_id"].values[i],
                 df.minor_xs(stock_symbol)["report_type"].values[i],
                df.minor_xs(stock_symbol)["pub_date"].values[i], df.minor_xs(stock_symbol)["type_id"].values[i],df.minor_xs(stock_symbol)["type"].values[i], df.minor_xs(stock_symbol)["profit_min"].values[i],
                 df.minor_xs(stock_symbol)["profit_max"].values[i],df.minor_xs(stock_symbol)["profit_last"].values[i],
                 df.minor_xs(stock_symbol)["profit_ratio_min"].values[i] / 100, df.minor_xs(stock_symbol)["profit_ratio_max"].values[i] / 100, df.minor_xs(stock_symbol)["content"].values[i])
            data_list.append(t)
        sql = "INSERT INTO performance_forecast_cn(security_lookup_id, company_id, code, name_x, end_date, report_type_id," \
              " report_type, pub_date, type_id, type_x, profit_min, profit_max," \
              " profit_last, profit_ratio_min, profit_ratio_max, content)"\
                "VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"\
                "ON DUPLICATE KEY UPDATE company_id=VALUES(company_id), code=VALUES(code), name_x=VALUES(name_x), end_date=VALUES(end_date)," \
              " report_type_id=VALUES(report_type_id)," \
              " report_type=VALUES(report_type), pub_date=VALUES(pub_date), type_id=VALUES(type_id), type_x=VALUES(type_x), profit_min=VALUES(profit_min), profit_max=VALUES(profit_max)," \
              " profit_last=VALUES(profit_last), profit_ratio_min=VALUES(profit_ratio_min), profit_ratio_max=VALUES(profit_ratio_max), content=VALUES(content)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:

        traceback.print_exc()
now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        finance.STK_FIN_FORCAST
    ).filter(
        finance.STK_FIN_FORCAST.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
