from jqdatasdk import *
import jqdatasdk
from pandas import DataFrame
import traceback
from helper import jqdata_helper
import MySQLdb
import cons_for_jqdata
import _thread
import datetime
import pymysql
import gevent
from concurrent.futures import ThreadPoolExecutor
import threading
from multiprocessing import Pool
import numpy as np
import re
import xarray
import warnings
# df_all = pd.DataFrame()
def __insert_price(security_id, df, stock_symbol, now1, conn):
    try:
        cur = conn.cursor()
        data_list = []
        code_num = re.sub("\D", "", stock_symbol)
        for i in range(0, len(df.minor_xs(stock_symbol).index)):
            t = (security_id, code_num, df.minor_xs(stock_symbol)["pubDate"].values[i], df.minor_xs(stock_symbol)["statDate"].values[i], df.minor_xs(stock_symbol)["investment_assets"].values[i],
                 df.minor_xs(stock_symbol)["total_investment_rate_of_return"].values[i]
            , df.minor_xs(stock_symbol)["net_investment_rate_of_return"].values[i], df.minor_xs(stock_symbol)["earned_premium"].values[i], df.minor_xs(stock_symbol)["earned_premium_growth_rate"].values[i],
                 df.minor_xs(stock_symbol)["payoff_cost"].values[i],df.minor_xs(stock_symbol)["compensation_rate"].values[i], df.minor_xs(stock_symbol)["not_expired_duty_reserve"].values[i],
                 df.minor_xs(stock_symbol)["outstanding_claims_reserve"].values[i],
            df.minor_xs(stock_symbol)["comprehensive_cost_ratio"].values[i], df.minor_xs(stock_symbol)["comprehensive_compensation_rate"].values[i], df.minor_xs(stock_symbol)["solvency_adequacy_ratio"].values[i],
                 df.minor_xs(stock_symbol)["actual_capital"].values[i],df.minor_xs(stock_symbol)["minimum_capital"].values[i],
                 )
            data_list.append(t)
        sql = "INSERT INTO insurance_indicator_cn(security_lookup_id, code, pubDate, endDate, investment_assets,"\
                                 "total_investment_rate_of_return, net_investment_rate_of_return, earned_premium,"\
                                 "earned_premium_growth_rate, payoff_cost, compensation_rate,"\
                                 "not_expired_duty_reserve, outstanding_claims_reserve, comprehensive_cost_ratio,"\
                                 "comprehensive_compensation_rate, solvency_adequacy_ratio, actual_capital,"\
                                 "minimum_capital)"\
                "VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"\
               "%s)"\
                "ON DUPLICATE KEY UPDATE code=VALUES(code), pubDate=VALUES(pubDate), investment_assets=VALUES(investment_assets),"\
                                 "total_investment_rate_of_return=VALUES(total_investment_rate_of_return), net_investment_rate_of_return=VALUES(net_investment_rate_of_return), earned_premium=VALUES(earned_premium),"\
                                 "earned_premium_growth_rate=VALUES(earned_premium_growth_rate), payoff_cost=VALUES(payoff_cost), compensation_rate=VALUES(compensation_rate),"\
                                 "not_expired_duty_reserve=VALUES(not_expired_duty_reserve), outstanding_claims_reserve=VALUES(outstanding_claims_reserve), comprehensive_cost_ratio=VALUES(comprehensive_cost_ratio),"\
                                 "comprehensive_compensation_rate=VALUES(comprehensive_compensation_rate), solvency_adequacy_ratio=VALUES(solvency_adequacy_ratio), actual_capital=VALUES(actual_capital),"\
                                 "minimum_capital=VALUES(minimum_capital)"
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " is inserting to the database")
        cur.executemany(sql, data_list)
        cur.close()
        conn.commit()
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " has been inserted into the database")
        now2 = datetime.datetime.now()
        print(" 共耗时 " + str(now2 - now1))
    except Exception as e:
        print(repr(e))

now1 = datetime.datetime.now()
warnings.filterwarnings("ignore")
jqdatasdk.auth(cons_for_jqdata.jq_user_super, cons_for_jqdata.jq_passwd_super)
conn = MySQLdb.connect(user=cons_for_jqdata.db_user, passwd=cons_for_jqdata.db_passwd, host=cons_for_jqdata.db_host,
                           db=cons_for_jqdata.db_name, port=cons_for_jqdata.db_port)
stock_symbols = get_all_securities(['stock']).index.values
for stock_symbol in stock_symbols:
    cur = conn.cursor()
    industry = get_industry(stock_symbol, date=now1)
    try:
        if "保险II" != industry[stock_symbol]["sw_l2"]["industry_name"]:
            continue
    except KeyError:
        print(get_security_info(stock_symbol).display_name + "(" + stock_symbol + ")" + " don't in sw_l2")
        continue
    code_num = re.sub("\D", "", stock_symbol)
    security_id = jqdata_helper.__get_stocks_id(code_num, cur)
    q = query(
        insurance_indicator
    ).filter(
        insurance_indicator.code == stock_symbol
    )
    df = get_fundamentals_continuously(q, end_date=now1, count = 20000)
    __insert_price(security_id,df,stock_symbol,now1,conn)
