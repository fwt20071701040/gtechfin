import MySQLdb
import numpy as np
from jqdatasdk import *
import re
import threading
import datetime
import pandas as pd
import time


def __get_stocks_id(code_num,cur):
    sql = "select id from security_lookup_cn where TICKER = '{}' and (sector is null or sector != 'index')".format(
        code_num)
    cur.execute(sql)
    info = cur.fetchall()
    cur.close()
    return info


def __get_indexes_id(code_num, cur):
    sql = "select id from security_lookup_cn where TICKER = '{}' and sector = 'index'".format(
        code_num)
    cur.execute(sql)
    info = cur.fetchall()
    cur.close()
    return info


def __insert_price(security_id, df, code_num, now1, conn):
    cur = conn.cursor()
    data_list = []
    for i in range(0, len(df)):
        time_struct = df.index[i]  # 协程和异步操作要转tuple
        # time_local = time.strftime(format(time_struct))
        t = (
        security_id[0], code_num, time_struct, np.float(df['open'][i]), np.float(df['high'][i]), np.float(df['low'][i])
        , np.float(df['close'][i]), np.float(df['volume'][i]), np.float(df['close'][i]))
        data_list.append(t)
    sql = "INSERT INTO security_min_price_cn(SECURITY_LOOKUP_ID,TICKER,time_x, OPEN_X, HIGH, LOW, CLOSE_X, VOLUME,ADJ_CLOSE)"\
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"\
            "ON DUPLICATE KEY UPDATE SECURITY_LOOKUP_ID=VALUES(SECURITY_LOOKUP_ID)," \
          "TICKER=VALUES(TICKER),time_x=VALUES(time_x),OPEN_X=VALUES(OPEN_X),HIGH=VALUES(HIGH),LOW=VALUES(LOW),CLOSE_X=VALUES(CLOSE_X),VOLUME=VALUES(VOLUME),ADJ_CLOSE=VALUES(ADJ_CLOSE)"

    print(code_num + " is inserting to the database")

    cur.executemany(sql, data_list)
    cur.close()
    conn.commit()
    now2 = datetime.datetime.now()
    print(" 共耗时 " + str(now2 - now1))


def insert_history_all_stocks_ticks(codes, index, now1, conn):
    # for index in range(len(codes)):
    cur = conn.cursor()
    code_num = re.sub("\D", "", codes[index])
    stock_id = __get_stocks_id(code_num, cur)
    if stock_id == ():
        return
    now2 = datetime.datetime.now()
    now_string = now2.strftime("%Y-%m-%d %H:%M:%S")
    start_time1 = "2004-12-01 23:00:00"
    end_time1 = "2008-01-01 23:00:00"
    start_time2 = "2008-01-01 23:00:00"
    end_time2 = "2011-01-01 23:00:00"
    start_time3 = "2011-01-01 23:00:00"
    end_time3 = "2014-01-01 23:00:00"
    start_time4 = "2014-01-01 23:00:00"
    end_time4 = "2017-01-01 23:00:00"
    start_time5 = "2017-01-01 23:00:00"
    end_time5 = now_string
    df1 = get_price(codes[index], start_date=start_time1, end_date=end_time1, frequency='minute')
    df2 = get_price(codes[index], start_date=start_time2, end_date=end_time2, frequency='minute')
    df3 = get_price(codes[index], start_date=start_time3, end_date=end_time3, frequency='minute')
    df4 = get_price(codes[index], start_date=start_time4, end_date=end_time4, frequency='minute')
    df5 = get_price(codes[index], start_date=start_time5, end_date=end_time5, frequency='minute')
    df = pd.concat([df1, df2, df3, df4, df5], axis=0).dropna(0)
    __insert_price(stock_id[0], df, code_num, now1, conn)
    print(codes[index] + " has been insert into the database")


def insert_latest_stocks_ticks(codes, index, now1, conn, specified_stock_latest_time):
    # for index in range(len(codes)):
    cur = conn.cursor()
    code_num = re.sub("\D", "", codes[index])
    stock_id = __get_stocks_id(code_num, cur)
    if stock_id == ():
        return
    now2 = datetime.datetime.now()
    now_string = now2.strftime("%Y-%m-%d %H:%M:%S")
    start_time = specified_stock_latest_time.strftime("%Y-%m-%d %H:%M:%S")
    end_time = now_string
    df = get_price(codes[index], start_date=start_time, end_date=end_time, frequency='minute')
    df = df.dropna(0)
    __insert_price(stock_id[0], df, code_num, now1, conn)
    print(codes[index] + " has been insert into the database")


def insert_history_all_indexes_ticks(codes, index, now1, conn):
    # for index in range(len(codes)):
    cur = conn.cursor()
    code_num = re.sub("\D", "", codes[index])
    # sector = get_sector_by_ticker(conn, code_num, True)
    index_id = __get_indexes_id(code_num, cur)
    if index_id == ():
        return
    now2 = datetime.datetime.now()
    now_string = now2.strftime("%Y-%m-%d %H:%M:%S")
    # print(stockId)
    start_time1 = "2004-12-01 23:00:00"
    end_time1 = "2008-01-01 23:00:00"
    start_time2 = "2008-01-01 23:00:00"
    end_time2 = "2011-01-01 23:00:00"
    start_time3 = "2011-01-01 23:00:00"
    end_time3 = "2014-01-01 23:00:00"
    start_time4 = "2014-01-01 23:00:00"
    end_time4 = "2017-01-01 23:00:00"
    start_time5 = "2017-01-01 23:00:00"
    end_time5 = now_string
    df1 = get_price(codes[index], start_date=start_time1, end_date=end_time1, frequency='minute')
    df2 = get_price(codes[index], start_date=start_time2, end_date=end_time2, frequency='minute')
    df3 = get_price(codes[index], start_date=start_time3, end_date=end_time3, frequency='minute')
    df4 = get_price(codes[index], start_date=start_time4, end_date=end_time4, frequency='minute')
    df5 = get_price(codes[index], start_date=start_time5, end_date=end_time5, frequency='minute')
    df = pd.concat([df1, df2, df3, df4, df5], axis=0).dropna(0)
    __insert_price(index_id[0], df, code_num, now1,conn)
    print(codes[index] + " has been insert into the database")


def insert_latest_indexes_ticks(codes, index, now1, conn, specified_index_latest_time):
    # for index in range(len(codes)):
    cur = conn.cursor()
    code_num = re.sub("\D", "", codes[index])
    index_id = __get_indexes_id(code_num, cur)
    if index_id == ():
        return
    now2 = datetime.datetime.now()
    now_string = now2.strftime("%Y-%m-%d %H:%M:%S")
    start_time = specified_index_latest_time.strftime("%Y-%m-%d %H:%M:%S")
    end_time = now_string
    df = get_price(codes[index], start_date=start_time, end_date=end_time, frequency='minute')
    df = df.dropna(0)
    __insert_price(index_id[0], df, code_num, now1, conn)
    print(codes[index] + " has been insert into the database")


def get_id_by_ticker_and_sector(conn, ticker, sector):
    cur = conn.cursor()
    if sector == 'index':
        sql = "select ID from security_lookup_cn where ticker = '" + ticker + "' and sector = 'index'"
    else:
        sql = "select ID from security_lookup_cn where ticker = '" + ticker + "' and (sector is null or sector != 'index')"
    cur.execute(sql)
    info = cur.fetchone()
    return info


def get_all_ids_from_min_price(conn):
    cur = conn.cursor()
    sql = "select security_lookup_id from security_min_price_cn GROUP BY security_lookup_id"
    cur.execute(sql)
    info = cur.fetchall()
    return info


def get_all_id_and_ticker(conn, index_flag):
    cur = conn.cursor()
    if index_flag:
        sql = "select ID,ticker from security_lookup_cn where SECTOR = 'index'"
    else:
        sql = "select ID,ticker from security_lookup_cn where (sector is null or sector != 'index')"
    cur.execute(sql)
    infos = cur.fetchall()
    return dict((y, x) for x, y in infos)


def get_specified_id_latest_time(conn, security_lookup_id):
    cur = conn.cursor()
    sql = "select time_x from security_min_price_cn where SECURITY_LOOKUP_ID = " + str(security_lookup_id) + " order by time_x desc limit 1"
    cur.execute(sql)
    info = cur.fetchone()
    return info
# def asynchronous(self):
#     # g_l 任务列表
#     # 定义了异步的函数: 这里用到了一个gevent.spawn方法
#     max_line = 10000  # 定义每次最大插入行数(max_line=10000,即一次插入10000行)
#     g_l = [gevent.spawn(self.run, i) for i in range(0, 3)]
#
#     # gevent.joinall 等待所以操作都执行完毕
#     gevent.joinall(g_l)
#     self.cur.close()  # 关闭游标
#     self.conn.close()  # 关闭pymysql连接


